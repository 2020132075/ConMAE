from __future__ import print_function, absolute_import
import time
import torch
from .utils.meters import AverageMeter

# def createdata(cl,tl):
    
#     return ct


class ClusterContrastTrainer(object):
    def __init__(self, encoder, memory=None):
        super(ClusterContrastTrainer, self).__init__()
        self.encoder = encoder
        self.memory = memory

    def train(self, epoch, data_loader, optimizer, print_freq=10, train_iters=400):
        self.encoder.train()

        #print(self.cm,self.tm,self.cmx,self.tmx)
        batch_time = AverageMeter()
        data_time = AverageMeter()

        losses = AverageMeter()

        end = time.time()

        for i in range(train_iters):
            # load data
            inputs = data_loader.next()#train_loader传入400条数据进行训练
            data_time.update(time.time() - end)

            # process inputs
            #f_inputs, soft_label, labels, clabels, tlabels, _ = self._veri_data(inputs)
            f_inputs, soft_label, labels  = self._vehicleid_data(inputs)
            
            f_out = self._forward(f_inputs)

            
            #print('shape',f_out.shape) 
            #l1 = self.memory(f_out, labels, ctl.cuda())
            loss = self.memory(f_out, soft_label, labels)

           
            #loss = l0 + l1
            #print(labels)
            optimizer.zero_grad()

            loss.backward()
            optimizer.step()

            losses.update(loss.item())
        
            
            
            
            # print log
            batch_time.update(time.time() - end)
            end = time.time()

            if (i + 1) % print_freq == 0:
                print('Epoch: [{}][{}/{}]\t'
                      'Time {:.3f} ({:.3f})\t'
                      'Data {:.3f} ({:.3f})\t'
                      'Loss {:.3f} ({:.3f})'
                      .format(epoch, i + 1, len(data_loader),
                              batch_time.val, batch_time.avg,
                              data_time.val, data_time.avg,
                              losses.val, losses.avg))

    def _veri_data(self, inputs):
        imgs_collect, address_collect, softlabel, pids_collect, cids_collect, indexes = inputs
        
        #imgs_collect = reshape_img(imgs_collect)
        # address_collect =address_collect[0]
        #pids_collect = pids_collect[0]
        cids_collect = cids_collect+1
        # imgs, address, pids, xids, indexes = inputs
        #xids = cid - 1
        time_need = []
        for i in range(len(address_collect)):
            tn = address_collect[i].split('_')[3]      
            time_need.append(int(tn))
        tids_collect = torch.tensor(time_need,dtype=torch.int)
                
        return imgs_collect.cuda(), softlabel.cuda(), pids_collect.cuda(), cids_collect.cuda(), tids_collect.cuda(), indexes.cuda()
   
    def _vehicleid_data(self, inputs):
        imgs_collect, address_collect, softlabel, pids_collect, cids_collect, indexes = inputs               
        return imgs_collect.cuda(), softlabel.cuda(), pids_collect.cuda()
   
    def _parse_label(self, inputs, find_label):
        
        imgs_collect, address_collect, softlabel, pids_collect, cids_collect, indexes = inputs
        label = []
        for i in range(len(address_collect)):
            cn = address_collect[i].split('_')[2]
            tn = address_collect[i].split('_')[3]   
            label.append(int(find_label[cn+tn]))       
        return torch.tensor(label)      #,dtype=torch.int
    

    def _forward(self, inputs):
        return self.encoder(inputs)
    


