# -*- coding: utf-8 -*-
"""
Created on Thu Apr 21 16:39:07 2022

@author: ZY
"""

import torch
import math
import time
from torch.nn import functional as F
import torch.nn.init as init
from torch import nn
from einops.layers.torch import Rearrange
# from clustercontrast.models.pooling import build_pooling_layer

# LayerNorm + Add.
class PreNormResidual(nn.Module):
    def __init__(self, dim, fn):
        super().__init__()
        self.fn = fn
        self.norm = nn.LayerNorm(dim)

    def forward(self, x):
        return self.fn(self.norm(x)) + x

# 一个MLP块：由2个全连接层和中间的激活函数构成.
def FeedForward(dim, expansion_factor = 4, dropout = 0.):
    return nn.Sequential(
        nn.Linear(dim, dim * expansion_factor),
        nn.GELU(),
        nn.Dropout(dropout),
        nn.Linear(dim * expansion_factor, dim),
        nn.Dropout(dropout)
    )

class st_Encoder(nn.Module):
    
    def __init__(self, image_size, patch_size, dim, depth, fc_dim = 2048, expansion_factor = 4, pretrained=True,
                 cut_at_pooling=False, norm=False, num_features=0, dropout = 0., num_classes=0, pooling_type='avg', **kwargs):
         
        super(st_Encoder, self).__init__()

        assert (image_size % patch_size) == 0, 'image must be divisible by patch size'
        num_patches = (image_size // patch_size) ** 2
        
        # self.base = nn.Sequential(
        #             Rearrange('b c (h p1) (w p2) -> b (h w) (p1 p2 c)', p1 = patch_size, p2 = patch_size),
        #             nn.Linear((patch_size ** 2) * 3, dim, 1),
                    
        #             *[nn.Sequential(
        #                 PreNormResidual(dim, nn.Sequential(
        #                     Rearrange('b n c -> b c n'),
        #                     FeedForward(num_patches, expansion_factor, dropout),
        #                     Rearrange('b c n -> b n c'),
        #                 )),
        #                 PreNormResidual(dim, FeedForward(dim, expansion_factor, dropout))
        #             ) for _ in range(depth)],
        #             nn.LayerNorm(dim),
        #             Rearrange('b n c -> b c n'),
        #             nn.AdaptiveAvgPool1d(1),
        #             Rearrange('b c () -> b c'),
        #             nn.Linear(dim, 2048)
        #             )
###############################################################################
        self.base_0 = Rearrange('b c (h p1) (w p2) -> b (h w) (p1 p2 c)', p1 = patch_size, p2 = patch_size)
                    
        self.link = nn.Linear(2048,1024)

        self.base_1 = nn.Sequential(nn.Linear(1024, dim, 1),
                    *[nn.Sequential(
                        PreNormResidual(dim, nn.Sequential(
                            Rearrange('b n c -> b c n'),
                            FeedForward(148, expansion_factor, dropout),
                            Rearrange('b c n -> b n c'),
                        )),
                        PreNormResidual(dim, FeedForward(dim, expansion_factor, dropout))
                    ) for _ in range(depth)],
                    nn.LayerNorm(dim),
                    Rearrange('b n c -> b c n'),
                    nn.AdaptiveAvgPool1d(1),
                    Rearrange('b c () -> b c'),
                    nn.Linear(dim, 2048)
                    )
        self.relu = nn.LeakyReLU(inplace=True)
        self.bn1 = nn.BatchNorm1d(2)
        self.f1 = nn.Linear(2,1024)     
        self.f2 = nn.Linear(1024,2048)   
        self.bn2 = nn.BatchNorm1d(2048)
        self.f3 = nn.Linear(2048,1024)   
        self.f4 = nn.Linear(1024,2048) 
        self.c = nn.Linear(2048,2048) 
        self.stc = nn.Linear(2048,992) 
##############################################################################
############################################################################### 
       
        # self.gap = build_pooling_layer(pooling_type)
        self.cut_at_pooling = cut_at_pooling
        
        if not self.cut_at_pooling:
            self.num_features = num_features
            self.norm = norm
            self.dropout = dropout
            self.has_embedding = num_features > 0
            self.num_classes = num_classes

            out_planes = 2048#resnet.fc.in_features

            # Append new layers
            if self.has_embedding:
                self.feat = nn.Linear(out_planes, self.num_features)
                self.feat_bn = nn.BatchNorm1d(self.num_features)
                init.kaiming_normal_(self.feat.weight, mode='fan_out')
                init.constant_(self.feat.bias, 0)
            else:
                # Change the num_features to CNN output channels
                self.num_features = out_planes
                self.feat_bn = nn.BatchNorm1d(self.num_features)
            self.feat_bn.bias.requires_grad_(False)
            if self.dropout > 0:
                self.drop = nn.Dropout(self.dropout)
            if self.num_classes > 0:
                self.classifier = nn.Linear(self.num_features, self.num_classes, bias=False)
                init.normal_(self.classifier.weight, std=0.001)
        init.constant_(self.feat_bn.weight, 1)
        init.constant_(self.feat_bn.bias, 0)
        
        if not pretrained:
            self.reset_params()
                    
    def forward(self, x, y):  
        ###############################################################################        
        y = self.bn1(y)
        y = self.f1(y)
        y = self.relu(y)
        y = self.f2(y)   
        
        y = self.bn2(y)
        y1 = self.f3(y)
        y1 = self.relu(y1)
        y1 = self.f4(y1)
        y = self.relu(y1+y)     
        
        y = self.c(y)
        
        ##############################################################################  
        x = self.base_0(x)
        # print(x.shape)
        x = x.reshape(x.shape[0],147,1024)
        y1 = self.link(y).unsqueeze(1)
        # print(y1.shape)
        y = self.stc(y)
        x = torch.cat((x,y1),1)
        x = self.base_1(x)
        
        # x = self.base(x)
        # print('done!')
        if self.cut_at_pooling:
            return y, x

        if self.has_embedding:
            bn_x = self.feat_bn(self.feat(x))
        else:
            bn_x = self.feat_bn(x)

        if (self.training is False):
            bn_x = F.normalize(bn_x)
            return y, bn_x

        if self.norm:
            bn_x = F.normalize(bn_x)
        elif self.has_embedding:
            bn_x = F.relu(bn_x)

        if self.dropout > 0:
            bn_x = self.drop(bn_x)

        if self.num_classes > 0:
            prob = self.classifier(bn_x)
        else:
            return y, bn_x

        return y, prob
    
    def reset_params(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                init.kaiming_normal_(m.weight, mode='fan_out')
                if m.bias is not None:
                    init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                init.constant_(m.weight, 1)
                init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm1d):
                init.constant_(m.weight, 1)
                init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                init.normal_(m.weight, std=0.001)
                if m.bias is not None:
                    init.constant_(m.bias, 0)
                    
# model=st_Encoder(image_size = 256,
#                 # channels = 3,
#                 patch_size = 16,
#                 dim = 512,
#                 depth = 12,
#                 fc_dim = 2048,
#                 )

def MIT(**kwargs):
    stmodel = st_Encoder(**kwargs)
    return stmodel
