from __future__ import absolute_import
from torch import nn
from torch.nn import functional as F
from torch.nn import init
import torchvision
import torch
from clustercontrast.models.pooling import build_pooling_layer
#from torchvision.models.utils import load_state_dict_from_url

__all__ = ['ResNet', 'resnet18', 'resnet34', 'resnet50', 'resnet101',
           'resnet152']


class ResNet(nn.Module):
    __factory = {
        18: torchvision.models.resnet18,
        34: torchvision.models.resnet34,
        50: torchvision.models.resnet50,
        101: torchvision.models.resnet101,
        152: torchvision.models.resnet152,
    }

    def __init__(self, depth, pretrained=True, cut_at_pooling=False, stclass = 992,
                 num_features=0, norm=False, dropout=0, num_classes=0, pooling_type='avg'):
        print('pooling_type: {}'.format(pooling_type))
        super(ResNet, self).__init__()
        self.pretrained = pretrained
        self.depth = depth
        self.cut_at_pooling = cut_at_pooling
        # Construct base (pretrained) resnet
        if depth not in ResNet.__factory:
            raise KeyError("Unsupported depth:", depth)
        resnet = ResNet.__factory[depth](pretrained=pretrained)
        resnet.layer4[0].conv2.stride = (1, 1)
        resnet.layer4[0].downsample[0].stride = (1, 1)
        self.base = nn.Sequential(
            resnet.conv1, resnet.bn1, resnet.relu, resnet.maxpool,
            resnet.layer1, resnet.layer2, resnet.layer3, resnet.layer4)
        self.gap = build_pooling_layer(pooling_type)

        if not self.cut_at_pooling:
            self.num_features = num_features
            self.norm = norm
            self.dropout = dropout
            self.has_embedding = (num_features > 0)
            self.num_classes = num_classes

            out_planes = resnet.fc.in_features
            # print('((((((((((((((((((((((((((((')
            # print('out_planes',out_planes)
            # Append new layers
            if self.has_embedding:
                self.feat = nn.Linear(out_planes, self.num_features)               
                self.feat_bn = nn.BatchNorm1d(self.num_features)
                init.kaiming_normal_(self.feat.weight, mode='fan_out')
                init.constant_(self.feat.bias, 0)
                
                self.featy = nn.Linear(out_planes, self.num_features)
                self.feat_bny = nn.BatchNorm1d(self.num_features)
                init.kaiming_normal_(self.featy.weight, mode='fan_out')
                init.constant_(self.featy.bias, 0)
            else:
                # Change the num_features to CNN output channels
                self.num_features = out_planes
                self.feat_bn = nn.BatchNorm1d(self.num_features)
                
                self.feat_bny = nn.BatchNorm1d(self.num_features)
                
            self.feat_bn.bias.requires_grad_(False)
            self.feat_bny.bias.requires_grad_(False)
            
            if self.dropout > 0:
                self.drop = nn.Dropout(self.dropout)
                self.dropy = nn.Dropout(self.dropouty)
                
            if self.num_classes > 0:
                self.classifier = nn.Linear(self.num_features, self.num_classes, bias=False)
                self.classifiery = nn.Linear(self.num_features, self.num_classes, bias=False)
                init.normal_(self.classifier.weight, std=0.001)
                init.normal_(self.classifiery.weight, std=0.001)
        init.constant_(self.feat_bn.weight, 1)
        init.constant_(self.feat_bn.bias, 0)
        
        init.constant_(self.feat_bny.weight, 1)
        init.constant_(self.feat_bny.bias, 0)
        # if not pretrained:
        #     self.reset_params()
##############################################################################
        self.relu = nn.LeakyReLU(inplace=True)
        self.bn1 = nn.BatchNorm1d(2)
        init.constant_(self.bn1.weight, 1)
        init.constant_(self.bn1.bias, 0)
        self.f1 = nn.Linear(2,1024)     
        init.kaiming_normal_(self.f1.weight, mode='fan_out')
        init.constant_(self.f1.bias, 0)
        self.f2 = nn.Linear(1024,2048)   
        init.kaiming_normal_(self.f2.weight, mode='fan_out')
        init.constant_(self.f2.bias, 0)
        self.bn2 = nn.BatchNorm1d(2048)
        init.constant_(self.bn2.weight, 1)
        init.constant_(self.bn2.bias, 0)
        self.f3 = nn.Linear(2048,1024)   
        init.kaiming_normal_(self.f3.weight, mode='fan_out')
        init.constant_(self.f3.bias, 0) 
        self.f4 = nn.Linear(1024,2048) 
        init.kaiming_normal_(self.f4.weight, mode='fan_out')
        init.constant_(self.f4.bias, 0)
        
        self.f5 = nn.Linear(2048,1024)   
        init.kaiming_normal_(self.f5.weight, mode='fan_out')
        init.constant_(self.f5.bias, 0) 
        self.f6 = nn.Linear(1024,2048) 
        init.kaiming_normal_(self.f6.weight, mode='fan_out')
        init.constant_(self.f6.bias, 0)
        
        self.c = nn.Linear(2048,2048) 
        init.kaiming_normal_(self.c.weight, mode='fan_out')
        init.constant_(self.c.bias, 0)

        self.stc = nn.Linear(2048,stclass) 
        init.kaiming_normal_(self.stc.weight, mode='fan_out')
        init.constant_(self.stc.bias, 0)
##############################################################################
        self.bn3 = nn.BatchNorm1d(2048)
        init.constant_(self.bn3.weight, 1)
        init.constant_(self.bn3.bias, 0)
        
        self.bn4 = nn.BatchNorm1d(2048)
        init.constant_(self.bn4.weight, 1)
        init.constant_(self.bn4.bias, 0)
        
        self.fc = nn.Linear(2048,2048) 
        init.kaiming_normal_(self.fc.weight, mode='fan_out')
        init.constant_(self.fc.bias, 0)
        
        # self.f6 = nn.Linear(1024,2048) 
        # init.kaiming_normal_(self.f6.weight, mode='fan_out')
        # init.constant_(self.f6.bias, 0)
        
        # self.f7 = nn.Linear(2048,1024) 
        # init.kaiming_normal_(self.f7.weight, mode='fan_out')
        # init.constant_(self.f7.bias, 0)
        
        # self.f8 = nn.Linear(1024,2048) 
        # init.kaiming_normal_(self.f8.weight, mode='fan_out')
        # init.constant_(self.f8.bias, 0)
        
        self.w1 = torch.nn.Parameter(torch.FloatTensor(1,2048) ,requires_grad=True)
        self.w1.data.fill_(1.0)
        self.w2 = torch.nn.Parameter(torch.FloatTensor(1,2048) ,requires_grad=True)
        self.w2.data.fill_(1.0) 
        
        self.w3 = torch.nn.Parameter(torch.FloatTensor(1,2048) ,requires_grad=True)
        self.w3.data.fill_(1.0)
        self.w4 = torch.nn.Parameter(torch.FloatTensor(1,2048) ,requires_grad=True)
        self.w4.data.fill_(1.0)
##############################################################################

        if not pretrained:
            self.reset_params()
##############################################################################
#create dic/test: has_embedding:False, training is False
#train:has_embedding: False, norm, num_classes<=0
#     def forward(self, x, y):#y=torch.ones(36,2048)
#         # print('forward_x.shape',x.shape)
#         bs = x.size(0)
#         x = self.base(x)
#         # print('base_x.shape',x.shape)
#         x = self.gap(x)
#         # print('gap_x.shape',x.shape)
#         x = x.view(x.size(0), -1)#batchsize*2048
#         # print('view_x.shape',x.shape)
# ###############################################################################        
#         y = self.bn1(y)
#         y = self.f1(y)
#         y = self.relu(y)
#         y = self.f2(y)   
        
#         y = self.bn2(y)
#         y1 = self.f3(y)
#         y1 = self.relu(y1)
#         y1 = self.f4(y1)
#         y = self.relu(y1+y)     
        
#         y = self.bn3(y)
#         y1 = self.f5(y)
#         y1 = self.relu(y1)
#         y1 = self.f6(y1)
#         y = self.relu(y1+y) 
        
#         y = self.fc(y)       
 ##################################################################################   
    def forward(self, x):#y=torch.ones(36,2048)
        # print('forward_x.shape',x.shape)
        bs = x.size(0)
        x = self.base(x)
        # print('base_x.shape',x.shape)
        x = self.gap(x)
        # print('gap_x.shape',x.shape)
        x = x.view(x.size(0), -1)#batchsize*2048
###############################################################################       
        if self.cut_at_pooling:
            # print('cut_at_pooling')
            return x

        if self.has_embedding:
            # print('has_embedding:True')
            bn_x = self.feat_bn(self.feat(x))
            # bn_y = self.feat_bny(self.feat(y))
        else:
            # print('has_embedding:False')
            bn_x = self.feat_bn(x)
            # bn_y = self.feat_bny(y)

        if (self.training is False):
            # print('training is False')
            bn_x = F.normalize(bn_x)
            # bn_y = F.normalize(bn_y)
            return bn_x
################################################################
        if self.norm:
            # print('norm')
            bn_x = F.normalize(bn_x)
            # bn_y = F.normalize(bn_y)
        elif self.has_embedding:
            # print('has_embedding')
            bn_x = F.relu(bn_x)
            # bn_y = F.relu(bn_y)
        # print('bn_x.shape',bn_x.shape)
        if self.dropout > 0:
            # print('dropout')
            bn_x = self.drop(bn_x)
            # bn_y = self.dropy(bn_y)
        if self.num_classes > 0:
            # print('num_classes>0')
            prob = self.classifier(bn_x)
            # proby = self.classifiery(bn_y)
        else:
            # print('num_classes<=0')
            
            return  bn_x
        
        # print('out:',prob.shape)
        return prob

    def reset_params(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                init.kaiming_normal_(m.weight, mode='fan_out')
                if m.bias is not None:
                    init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                init.constant_(m.weight, 1)
                init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm1d):
                init.constant_(m.weight, 1)
                init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                init.normal_(m.weight, std=0.001)
                if m.bias is not None:
                    init.constant_(m.bias, 0)


def resnet18(**kwargs):
    return ResNet(18, **kwargs)


def resnet34(**kwargs):
    return ResNet(34, **kwargs)


def resnet50(**kwargs):
    return ResNet(50, **kwargs)


def resnet101(**kwargs):
    return ResNet(101, **kwargs)


def resnet152(**kwargs):
    return ResNet(152, **kwargs)
