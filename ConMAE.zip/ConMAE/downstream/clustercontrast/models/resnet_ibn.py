from __future__ import absolute_import

from torch import nn
from torch.nn import functional as F
from torch.nn import init
import torchvision
import torch
from .pooling import build_pooling_layer

from .resnet_ibn_a import resnet50_ibn_a, resnet101_ibn_a


__all__ = ['ResNetIBN', 'resnet_ibn50a', 'resnet_ibn101a']


class ResNetIBN(nn.Module):
    __factory = {
        '50a': resnet50_ibn_a,
        '101a': resnet101_ibn_a
    }

    def __init__(self, depth, pretrained=True, cut_at_pooling=False, stclass = 992,
                 num_features=0, norm=False, dropout=0, num_classes=0, pooling_type='avg'):

        print('pooling_type: {}'.format(pooling_type))
        super(ResNetIBN, self).__init__()

        self.depth = depth
        self.pretrained = pretrained
        self.cut_at_pooling = cut_at_pooling

        resnet = ResNetIBN.__factory[depth](pretrained=pretrained)
        resnet.layer4[0].conv2.stride = (1, 1)
        resnet.layer4[0].downsample[0].stride = (1, 1)

        self.base = nn.Sequential(
            resnet.conv1, resnet.bn1, resnet.relu, resnet.maxpool,
            resnet.layer1, resnet.layer2, resnet.layer3, resnet.layer4)

        self.gap = build_pooling_layer(pooling_type)

        if not self.cut_at_pooling:
            self.num_features = num_features
            self.norm = norm
            self.dropout = dropout
            self.has_embedding = num_features > 0
            self.num_classes = num_classes

            out_planes = resnet.fc.in_features

            # Append new layers
            if self.has_embedding:
                self.feat = nn.Linear(out_planes, self.num_features)
                self.feat_bn = nn.BatchNorm1d(self.num_features)
                init.kaiming_normal_(self.feat.weight, mode='fan_out')
                init.constant_(self.feat.bias, 0)
            else:
                # Change the num_features to CNN output channels
                self.num_features = out_planes
                self.feat_bn = nn.BatchNorm1d(self.num_features)
            self.feat_bn.bias.requires_grad_(False)
            if self.dropout > 0:
                self.drop = nn.Dropout(self.dropout)
            if self.num_classes > 0:
                self.classifier = nn.Linear(self.num_features, self.num_classes, bias=False)
                init.normal_(self.classifier.weight, std=0.001)

        init.constant_(self.feat_bn.weight, 1)
        init.constant_(self.feat_bn.bias, 0)
##############################################################################
        self.relu = nn.LeakyReLU(inplace=True)
        self.bn1 = nn.BatchNorm1d(2)
        init.constant_(self.bn1.weight, 1)
        init.constant_(self.bn1.bias, 0)
        self.f1 = nn.Linear(2,1024)     
        init.kaiming_normal_(self.f1.weight, mode='fan_out')
        init.constant_(self.f1.bias, 0)
        self.f2 = nn.Linear(1024,2048)   
        init.kaiming_normal_(self.f2.weight, mode='fan_out')
        init.constant_(self.f2.bias, 0)
        self.bn2 = nn.BatchNorm1d(2048)
        init.constant_(self.bn2.weight, 1)
        init.constant_(self.bn2.bias, 0)
        self.f3 = nn.Linear(2048,1024)   
        init.kaiming_normal_(self.f3.weight, mode='fan_out')
        init.constant_(self.f3.bias, 0) 
        self.f4 = nn.Linear(1024,2048) 
        init.kaiming_normal_(self.f4.weight, mode='fan_out')
        init.constant_(self.f4.bias, 0)
        
        self.c = nn.Linear(2048,2048) 
        init.kaiming_normal_(self.c.weight, mode='fan_out')
        init.constant_(self.c.bias, 0)

        self.stc = nn.Linear(2048,stclass) 
        init.kaiming_normal_(self.stc.weight, mode='fan_out')
        init.constant_(self.stc.bias, 0)
    
        
        self.w1 = torch.nn.Parameter(torch.FloatTensor(1,2048) ,requires_grad=True)
        self.w1.data.fill_(1.0)
        self.w2 = torch.nn.Parameter(torch.FloatTensor(1,2048) ,requires_grad=True)
        self.w2.data.fill_(1.0) 
#################################################################################        

        if not pretrained:
            self.reset_params()

    def forward(self, x, y):
        x = self.base(x)

        x = self.gap(x)
        x = x.view(x.size(0), -1)
###############################################################################        
        y = self.bn1(y)
        y = self.f1(y)
        y = self.relu(y)
        y = self.f2(y)   
        
        y = self.bn2(y)
        y1 = self.f3(y)
        y1 = self.relu(y1)
        y1 = self.f4(y1)
        y = self.relu(y1+y)     
        
        y = self.c(y)      
        x = (self.w1 * x * y) + (self.w2 * x)
        y = self.stc(y)
 ##################################################################################    
        if self.cut_at_pooling:
            return y, x

        if self.has_embedding:
            bn_x = self.feat_bn(self.feat(x))
        else:
            bn_x = self.feat_bn(x)

        if self.training is False:
            bn_x = F.normalize(bn_x)
            return y, bn_x

        if self.norm:
            bn_x = F.normalize(bn_x)
        elif self.has_embedding:
            bn_x = F.relu(bn_x)

        if self.dropout > 0:
            bn_x = self.drop(bn_x)

        if self.num_classes > 0:
            prob = self.classifier(bn_x)
        else:
            return y, bn_x

        return y, prob

    def reset_params(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                init.kaiming_normal_(m.weight, mode='fan_out')
                if m.bias is not None:
                    init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                init.constant_(m.weight, 1)
                init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm1d):
                init.constant_(m.weight, 1)
                init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                init.normal_(m.weight, std=0.001)
                if m.bias is not None:
                    init.constant_(m.bias, 0)


def resnet_ibn50a(**kwargs):
    return ResNetIBN('50a', **kwargs)


def resnet_ibn101a(**kwargs):
    return ResNetIBN('101a', **kwargs)
